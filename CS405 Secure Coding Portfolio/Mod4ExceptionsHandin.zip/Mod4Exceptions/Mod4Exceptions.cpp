// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception> // for std::exception
#include <stdexcept> // for std::runtime_error


// Defining a custom exception class derived from std::exception
class MyCustomException : public std::exception
{
public:
    virtual const char* what() const noexcept override
    {
        return "MyCustomException: Something went wrong in the custom application logic.";
    }
};


bool do_even_more_custom_application_logic()
{
    

    std::cout << "Running Even More Custom Application Logic." << std::endl;
    
    //Throw any standard exception
	throw std::runtime_error("An error occurred in do_even_more_custom_application_logic.");
    return true;
}
void do_custom_application_logic()
{
    
    std::cout << "Running Custom Application Logic." << std::endl;
    
    // Wrap the call to do_even_more_custom_application_logic() with a try-catch block
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }

	// Catch any std::exception thrown by do_even_more_custom_application_logic
    catch (const std::exception& e)
    {
        std::cout << "Exception caught in do_custom_application_logic: " << e.what() << std::endl;
	}
   
    std::cout << "Leaving Custom Application Logic." << std::endl;

	throw MyCustomException();
}

float divide(float num, float den)
{
    
	// Throw an exception to deal with divide by zero errors using a standard C++ defined exception
    if (den == 0)
    {
        throw std::invalid_argument("Error: Attemtped to divide by zero.");
    }
    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        auto result = divide(numerator, denominator);
		std::cout << "divide(" << numerator << ", " << (denominator) << ") = " << result << std::endl;
    }

    // Catch ONLY the exception thrown by divide
    catch (const std::invalid_argument& e)
    {
        std::cout << "Exception caught in do_division: " << e.what() << std::endl;
    }

}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const MyCustomException& e)
    {
        std::cout << "Caught MyCustomException in main: " << e.what() << std::endl;
    }
    catch (const std::exception& e)
    {
        std::cout << "Caught std::exception in main: " << e.what() << std::endl;
    }
    catch (...)
    {
        std::cout << "Caught an uncaught exception in main." << std::endl;
	}

	return 0;

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu